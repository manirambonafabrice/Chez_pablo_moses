// set up before Leaflet files to test L#noConflict later
L = 'test';

